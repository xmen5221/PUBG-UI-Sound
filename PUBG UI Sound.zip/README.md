# PUBG UI Sound


Flash this And get Cool PUBG UI SOUNDS In your Android . 
1) Phone Lock = M24 suppressed Sound. 
2) Phone Unlock = Kar 98 Suppressed. 
3) Touch_effect = Groza Single shot Suppressed. 
4) Low battery = Dacia Horn.
5) Screenshot = Scar-L Reload.


Have A nice Day 👍 . You can contact me For Any Suggestions @ telegram. https://t.me/Xmen06    @Xmen06

If U Wanna Donate Because U Loved My Work 
Then U Made My Day Thanks... 

